# SHIFT MANAGER 完全版

この版では以下が入っています。

- スタッフ全員で同じデータを共有
- シフト追加・編集
- 希望シフト提出
- 管理者だけシフト編集
- 月間表示
- LINE共有用テキスト生成
- イベント登録
- メール＋パスワード認証
- 最初に登録したユーザーを自動で管理者に設定
- 2人目以降はスタッフ権限

## 使うもの

- GitHub Pages（画面の公開）
- Supabase（共有データ・ログイン）

## セットアップ手順

1. Supabaseで新しいProjectを作成
2. Supabaseの「SQL Editor」を開く
3. `supabase_setup.sql` の中身を全文貼って Run
4. Supabaseの Project Settings / API から
   - Project URL
   - anon public key
   を確認
5. `index.html` をGitHubの `shift-manager` にアップロードして既存の `index.html` を置き換える
6. 公開中のGitHub Pages URLを開く
7. 初回画面で Project URL と anon public key を入力
8. 最初に新規登録した人が管理者
9. 2人目以降はスタッフ

## 権限

### 管理者
- スタッフ追加・変更・削除
- シフト追加・編集・削除
- イベント登録
- 希望シフトの承認・却下
- 全員のシフト閲覧
- 月間表示
- LINE共有

### スタッフ
- シフト閲覧
- 月間表示
- 自分の希望シフト提出
- 自分の希望提出状況確認
- LINE共有画面の閲覧

## 注意
GitHub Pagesだけでは複数端末でデータ共有できません。
この完全版ではSupabaseを使って共有を実現します。
