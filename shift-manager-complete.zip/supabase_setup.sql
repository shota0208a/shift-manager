-- SHIFT MANAGER Supabase setup
-- Supabase > SQL Editor にこのファイル全文を貼り付けて Run してください。

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'staff' check (role in ('admin','staff')),
  created_at timestamptz default now()
);

create table if not exists public.staff (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  sort_order integer default 0,
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists public.shifts (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references public.staff(id) on delete cascade,
  date date not null,
  display_text text,
  role text,
  created_at timestamptz default now(),
  unique(staff_id,date)
);

create table if not exists public.shift_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  user_email text,
  date date not null,
  request_type text not null check (request_type in ('available','prefer','prefer_off','off')),
  start_text text,
  end_text text,
  memo text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  date date not null unique,
  name text,
  time_text text,
  created_at timestamptz default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  admin_exists boolean;
begin
  select exists(select 1 from public.profiles where role='admin') into admin_exists;
  insert into public.profiles(id,email,role)
  values(new.id,new.email,case when admin_exists then 'staff' else 'admin' end);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

alter table public.profiles enable row level security;
alter table public.staff enable row level security;
alter table public.shifts enable row level security;
alter table public.shift_requests enable row level security;
alter table public.events enable row level security;

drop policy if exists "profiles self read" on public.profiles;
create policy "profiles self read" on public.profiles
for select to authenticated using (id=auth.uid() or public.is_admin());

drop policy if exists "staff read" on public.staff;
create policy "staff read" on public.staff
for select to authenticated using (true);

drop policy if exists "staff admin write" on public.staff;
create policy "staff admin write" on public.staff
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "shifts read" on public.shifts;
create policy "shifts read" on public.shifts
for select to authenticated using (true);

drop policy if exists "shifts admin write" on public.shifts;
create policy "shifts admin write" on public.shifts
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "events read" on public.events;
create policy "events read" on public.events
for select to authenticated using (true);

drop policy if exists "events admin write" on public.events;
create policy "events admin write" on public.events
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "requests own read" on public.shift_requests;
create policy "requests own read" on public.shift_requests
for select to authenticated using (user_id=auth.uid() or public.is_admin());

drop policy if exists "requests own insert" on public.shift_requests;
create policy "requests own insert" on public.shift_requests
for insert to authenticated with check (user_id=auth.uid());

drop policy if exists "requests admin update" on public.shift_requests;
create policy "requests admin update" on public.shift_requests
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "requests own delete" on public.shift_requests;
create policy "requests own delete" on public.shift_requests
for delete to authenticated using (user_id=auth.uid() or public.is_admin());

-- 初期スタッフ（不要なら削除可）
insert into public.staff(name,sort_order)
select * from (values
 ('Gian',1),('Shota',2),('Shoki',3),('Sho',4),('Taro',5)
) as v(name,sort_order)
where not exists (select 1 from public.staff);
