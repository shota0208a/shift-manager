'use client'

import { useEffect, useMemo, useState } from 'react'

type Staff = { id: string; name: string }
type ShiftMap = Record<string, Record<string, string>>

type Day = {
  key: string
  date: number
  weekday: string
  weekend?: 'sat' | 'sun'
}

const INITIAL_STAFF: Staff[] = [
  { id: 'gian', name: 'Gian' },
  { id: 'shota', name: 'Shota' },
  { id: 'shoki', name: 'Shoki' },
  { id: 'sho', name: 'Sho' },
  { id: 'taro', name: 'Taro' },
]

const DAYS: Day[] = [
  { key: '2026-09-07', date: 7, weekday: '月' },
  { key: '2026-09-08', date: 8, weekday: '火' },
  { key: '2026-09-09', date: 9, weekday: '水' },
  { key: '2026-09-10', date: 10, weekday: '木' },
  { key: '2026-09-11', date: 11, weekday: '金' },
  { key: '2026-09-12', date: 12, weekday: '土', weekend: 'sat' },
  { key: '2026-09-13', date: 13, weekday: '日', weekend: 'sun' },
]

const INITIAL_SHIFTS: ShiftMap = {
  gian: {
    '2026-09-07': '19〜L',
    '2026-09-08': '19〜L',
    '2026-09-11': '24〜L',
    '2026-09-12': '24〜L',
  },
  shota: {
    '2026-09-07': '23〜L',
    '2026-09-08': '23〜L',
    '2026-09-09': '23〜L',
    '2026-09-11': '24〜L',
  },
  shoki: {
    '2026-09-08': '24〜L',
    '2026-09-09': '24〜L',
    '2026-09-11': '24〜L',
  },
  sho: {
    '2026-09-08': '19〜L',
    '2026-09-09': '24〜L',
    '2026-09-11': '24〜L',
  },
  taro: {
    '2026-09-08': '18〜23',
    '2026-09-09': '18〜5',
    '2026-09-10': '18〜5',
    '2026-09-11': '18〜5',
    '2026-09-12': '18〜5',
  },
}

const SHIFT_OPTIONS = ['', '18〜23', '18〜5', '19〜L', '23〜L', '24〜L', 'after〜L', '休']

export default function HomePage() {
  const [staff, setStaff] = useState<Staff[]>(INITIAL_STAFF)
  const [shifts, setShifts] = useState<ShiftMap>(INITIAL_SHIFTS)
  const [ready, setReady] = useState(false)
  const [newName, setNewName] = useState('')
  const [editing, setEditing] = useState<{ staffId: string; dayKey: string } | null>(null)
  const [customValue, setCustomValue] = useState('')

  useEffect(() => {
    try {
      const savedStaff = localStorage.getItem('shift-manager-staff')
      const savedShifts = localStorage.getItem('shift-manager-shifts')
      if (savedStaff) setStaff(JSON.parse(savedStaff))
      if (savedShifts) setShifts(JSON.parse(savedShifts))
    } catch {}
    setReady(true)
  }, [])

  useEffect(() => {
    if (!ready) return
    localStorage.setItem('shift-manager-staff', JSON.stringify(staff))
    localStorage.setItem('shift-manager-shifts', JSON.stringify(shifts))
  }, [staff, shifts, ready])

  const selectedValue = useMemo(() => {
    if (!editing) return ''
    return shifts[editing.staffId]?.[editing.dayKey] ?? ''
  }, [editing, shifts])

  function setShift(staffId: string, dayKey: string, value: string) {
    setShifts(prev => ({
      ...prev,
      [staffId]: { ...(prev[staffId] || {}), [dayKey]: value },
    }))
  }

  function addStaff() {
    const name = newName.trim()
    if (!name) return
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`
    setStaff(prev => [...prev, { id, name }])
    setNewName('')
  }

  function renameStaff(id: string) {
    const current = staff.find(s => s.id === id)?.name ?? ''
    const next = window.prompt('スタッフ名を変更', current)?.trim()
    if (!next) return
    setStaff(prev => prev.map(s => (s.id === id ? { ...s, name: next } : s)))
  }

  function deleteStaff(id: string) {
    const target = staff.find(s => s.id === id)
    if (!target) return
    if (!window.confirm(`${target.name} を削除しますか？`)) return
    setStaff(prev => prev.filter(s => s.id !== id))
    setShifts(prev => {
      const copy = { ...prev }
      delete copy[id]
      return copy
    })
  }

  function resetSample() {
    if (!window.confirm('STEP1のサンプル状態に戻しますか？')) return
    setStaff(INITIAL_STAFF)
    setShifts(INITIAL_SHIFTS)
  }

  return (
    <main className="min-h-screen pb-12">
      <div className="mx-auto max-w-6xl px-3 pt-4 sm:px-6">
        <header className="mb-4 rounded-2xl bg-white p-4 shadow-sm">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-slate-500">SHIFT MANAGER / STEP1</p>
              <h1 className="mt-1 text-2xl font-bold tracking-tight">週間シフト</h1>
              <p className="mt-1 text-sm text-slate-500">セルをタップして勤務時間を編集できます。</p>
            </div>
            <button onClick={resetSample} className="rounded-xl border px-3 py-2 text-xs font-semibold text-slate-600 active:bg-slate-100">
              リセット
            </button>
          </div>
        </header>

        <section className="mb-4 rounded-2xl bg-white p-3 shadow-sm">
          <div className="flex gap-2">
            <input
              value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addStaff()}
              placeholder="スタッフ名を追加"
              className="min-w-0 flex-1 rounded-xl border border-slate-200 px-3 py-3 text-base outline-none focus:border-slate-400"
            />
            <button onClick={addStaff} className="rounded-xl bg-slate-900 px-4 py-3 font-bold text-white active:scale-[0.98]">
              追加
            </button>
          </div>
        </section>

        <section className="overflow-hidden rounded-2xl bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="min-w-[760px] w-full border-collapse text-center text-sm">
              <thead>
                <tr>
                  <th className="sticky left-0 z-20 min-w-[118px] border-b border-r bg-slate-50 p-2 text-left font-bold">STAFF</th>
                  {DAYS.map(day => (
                    <th
                      key={day.key}
                      className={`min-w-[88px] border-b border-r p-2 ${
                        day.weekend === 'sat' ? 'bg-sky-50' : day.weekend === 'sun' ? 'bg-rose-50' : 'bg-slate-50'
                      }`}
                    >
                      <div className="text-base font-extrabold">{String(day.date).padStart(2, '0')}</div>
                      <div className={`text-xs ${day.weekend === 'sat' ? 'text-sky-600' : day.weekend === 'sun' ? 'text-rose-600' : 'text-slate-500'}`}>
                        {day.weekday}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {staff.map(person => (
                  <tr key={person.id}>
                    <th className="sticky left-0 z-10 border-b border-r bg-white p-2 text-left align-middle">
                      <div className="flex items-center justify-between gap-1">
                        <button onClick={() => renameStaff(person.id)} className="truncate font-bold underline-offset-2 active:underline">
                          {person.name}
                        </button>
                        <button onClick={() => deleteStaff(person.id)} aria-label={`${person.name}を削除`} className="rounded-lg px-2 py-1 text-xs text-slate-400 active:bg-rose-50 active:text-rose-600">×</button>
                      </div>
                    </th>
                    {DAYS.map(day => {
                      const value = shifts[person.id]?.[day.key] ?? ''
                      return (
                        <td
                          key={day.key}
                          className={`border-b border-r p-1 ${
                            day.weekend === 'sat' ? 'bg-sky-50/50' : day.weekend === 'sun' ? 'bg-rose-50/50' : 'bg-white'
                          }`}
                        >
                          <button
                            onClick={() => {
                              setEditing({ staffId: person.id, dayKey: day.key })
                              setCustomValue(value)
                            }}
                            className={`min-h-12 w-full rounded-lg px-1 py-2 font-semibold active:scale-[0.98] ${
                              value === '休' ? 'bg-slate-100 text-slate-400' : value ? 'bg-amber-50 text-slate-800' : 'text-slate-300'
                            }`}
                          >
                            {value || '＋'}
                          </button>
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <p className="mt-3 px-1 text-xs leading-5 text-slate-500">
          ※ データはこのブラウザ内に保存されます。STEP1ではログイン・DB・AI自動作成・LINE共有は未実装です。
        </p>
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/35 sm:items-center sm:justify-center" onClick={() => setEditing(null)}>
          <div className="w-full rounded-t-3xl bg-white p-4 shadow-2xl sm:max-w-md sm:rounded-3xl" onClick={e => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-500">勤務時間を編集</p>
                <h2 className="text-lg font-bold">
                  {staff.find(s => s.id === editing.staffId)?.name} / {DAYS.find(d => d.key === editing.dayKey)?.date}日
                </h2>
              </div>
              <button onClick={() => setEditing(null)} className="rounded-full bg-slate-100 px-3 py-2 text-sm font-bold">閉じる</button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {SHIFT_OPTIONS.map(option => (
                <button
                  key={option || 'blank'}
                  onClick={() => {
                    setShift(editing.staffId, editing.dayKey, option)
                    setEditing(null)
                  }}
                  className={`rounded-xl border p-3 text-base font-bold ${selectedValue === option ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white'}`}
                >
                  {option || '空欄'}
                </button>
              ))}
            </div>

            <div className="mt-3 flex gap-2">
              <input
                value={customValue}
                onChange={e => setCustomValue(e.target.value)}
                placeholder="例：25〜6"
                className="min-w-0 flex-1 rounded-xl border border-slate-200 px-3 py-3 outline-none focus:border-slate-400"
              />
              <button
                onClick={() => {
                  setShift(editing.staffId, editing.dayKey, customValue.trim())
                  setEditing(null)
                }}
                className="rounded-xl bg-slate-900 px-4 py-3 font-bold text-white"
              >
                保存
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
