# shift-manager

店舗向けシフト管理WebアプリのSTEP1です。

## 実装済み
- Next.js + TypeScript + Tailwind CSS
- スマホ優先の週間シフト表
- 横軸：日付 / 縦軸：スタッフ
- シフトセルをタップして勤務時間編集
- 18〜23 / 18〜5 / 24〜L / after〜L などのプリセット
- 自由入力にも対応
- 土曜は薄い青、日曜は薄い赤
- スタッフ追加・名前変更・削除
- 初期スタッフ：Gian / Shota / Shoki / Sho / Taro
- localStorageによるブラウザ内保存

## ローカル起動
```bash
npm install
npm run dev
```

## Vercel
このリポジトリをVercelへImportすればデプロイできます。

STEP1ではSupabase・ログイン・AI自動シフト・LINE共有・画像出力は未実装です。
